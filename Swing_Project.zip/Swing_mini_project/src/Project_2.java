import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Project_2 {

    public static void main(String[] args) {
        JFrame frame = new JFrame("User Preferences");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(250, 250);
        frame.setLayout(new FlowLayout());

        JLabel nameLabel = new JLabel("Enter Name:");
        JTextField nameField = new JTextField(10);

        JRadioButton r1 = new JRadioButton("Male");
        JRadioButton r2 = new JRadioButton("Female");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(r1);
        genderGroup.add(r2);

        JCheckBox c1 = new JCheckBox("Like Coffee");
        JCheckBox c2 = new JCheckBox("Like Tea");

        JButton submit = new JButton("Submit");
        JLabel result = new JLabel("Your selection will appear here.");

        frame.add(nameLabel);
        frame.add(nameField);

        frame.add(new JLabel("Select Gender:"));
        frame.add(r1);
        frame.add(r2);

        frame.add(new JLabel("Select Preferences:"));
        frame.add(c1);
        frame.add(c2);

        frame.add(submit);
        frame.add(result);

        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                if (name.isEmpty()) {
                    result.setText("Please enter a name.");
                    return;
                }

                String title = "";
                if (r1.isSelected()) {
                    title = "Mr.";
                } else if (r2.isSelected()) {
                    title = "Ms.";
                } else {
                    result.setText("Please select a gender.");
                    return;
                }

                StringBuilder output = new StringBuilder();
                output.append(title).append(" ").append(name).append(" ");

                if (!c1.isSelected() && !c2.isSelected()) {
                    output.append("doesn't like coffee or tea.");
                } else {
                    if (c1.isSelected()) output.append("likes coffee, ");
                    if (c2.isSelected()) output.append("likes tea, ");
                    if (output.toString().endsWith(", ")) {
                        output.setLength(output.length() - 2);
                        output.append(".");
                    }
                }

                result.setText(output.toString());
            }
        });

        frame.setVisible(true);
    }
}
