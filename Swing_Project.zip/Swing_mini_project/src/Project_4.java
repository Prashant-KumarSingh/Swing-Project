import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Project_4 extends MouseMotionAdapter {

    JFrame frame;
    DrawPanel drawPanel;

    public static void main(String[] args) {
        new Project_4();
    }

    Project_4() {
        frame = new JFrame("Mouse Drawing - Project 4");

        drawPanel = new DrawPanel();
        drawPanel.addMouseMotionListener(this);

        frame.add(drawPanel);
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        drawPanel.addPoint(e.getPoint());
    }

    class DrawPanel extends JPanel {
        java.util.List<Point> points = new ArrayList<>();

        public void addPoint(Point p) {
            points.add(p);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(Color.RED);
            for (Point p : points) {
                g.fillRect(p.x, p.y, 5, 5);
            }
        }
    }
}
