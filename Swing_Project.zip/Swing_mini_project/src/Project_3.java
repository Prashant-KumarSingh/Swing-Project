import java.awt.*;
import javax.swing.*;

public class Project_3 extends Canvas {

    public static void main(String[] args) {
        JFrame jf = new JFrame("Simple Face Drawing - Project 3");

        Project_3 canvas = new Project_3();
        jf.add(canvas);

        jf.setSize(500, 250);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        // Enable anti-aliasing for smoother shapes
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);

        // Face outline
        g.setColor(Color.BLACK);
        g.drawRect(150, 40, 140, 90);

        // Eyes 
        g.setColor(Color.BLACK);
        g.drawOval(120, 60, 30, 30); 
        g.drawOval(290, 60, 30, 30); 

        // Pupils 
        g.setColor(Color.RED);
        g.fillOval(160, 60, 30, 30); 
        g.fillOval(250, 60, 30, 30); 

        // Smile
        g.setColor(Color.BLUE);
        g.drawArc(200, 60, 50, 50, 240, 60);
    }
}
